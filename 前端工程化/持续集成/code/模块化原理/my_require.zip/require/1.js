

// 1.js
require(['2.js','3.js'],function(a, b) {
	console.log('1.js loaded   init',a,b);
})


// 3 4 2 1