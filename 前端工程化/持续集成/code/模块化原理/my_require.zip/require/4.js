


define(['6.js'],function(a) {
	console.log('4.js loaded', a)
	return '4.js return'
})