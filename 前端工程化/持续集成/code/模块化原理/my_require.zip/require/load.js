


for(var i=0;i<10000;i++){
	
}
console.log(1, new Date());
